#!/usr/bin/env bash
# shellcheck disable=SC2034

# Hiroki OS - profiledef.sh
# Archiso profil tanımlaması - Sakura 1.0
# https://wiki.archlinux.org/title/Archiso

iso_name="hiroki-os"
iso_label="HIROKI_OS"
iso_publisher="Hiroki OS Project <https://hiroki-os.org>"
iso_application="Hiroki OS 1.0 Sakura"
iso_version="1.0"
install_dir="arch"
buildmodes=('iso')
bootmodes=('bios.syslinux' 'uefi.grub')
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'zstd' '-b' '1M' '-Xcompression-level' '8')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/etc/gshadow"]="0:0:400"
  ["/root"]="0:0:750"
  ["/usr/bin/hiroki-hw-detect"]="0:0:755"
  ["/usr/bin/hiroki-de-selector"]="0:0:755"
  ["/usr/bin/hiroki-welcome"]="0:0:755"
  ["/usr/bin/hiroki-theme-manager"]="0:0:755"
  ["/usr/bin/hiroki-update"]="0:0:755"
  ["/usr/bin/hiroki-snapshot"]="0:0:755"
  ["/usr/bin/hiroki-driver-manager"]="0:0:755"
  ["/usr/share/hiroki/de-selector/hiroki-de-selector.py"]="0:0:755"
  ["/usr/share/hiroki-welcome/hiroki-welcome.py"]="0:0:755"
  ["/etc/hiroki/post-install/hiroki-post-install.sh"]="0:0:755"
  ["/etc/hiroki/post-install/apply-theme.sh"]="0:0:755"
  ["/etc/hiroki/post-install/enable-services.sh"]="0:0:755"
  ["/etc/hiroki/post-install/setup-displaymanager.sh"]="0:0:755"
  ["/usr/bin/hiroki-dm"]="0:0:755"
  ["/usr/bin/hiroki-dm-wrapper"]="0:0:755"
  ["/usr/bin/hiroki-dm-xinit"]="0:0:755"
  ["/usr/bin/hiroki-dm-gui"]="0:0:755"
  ["/usr/bin/hiroki-installer"]="0:0:755"
  ["/usr/bin/hiroki-installer-launch"]="0:0:755"
  ["/etc/sudoers.d/10-live"]="0:0:0440"
)
