#!/bin/bash
# Archiso hook: SquashFS olusturulmadan once calisir

# Live kullanici olustur
useradd -m -G wheel,video,audio,storage,network,users -s /bin/bash live 2>/dev/null || true

# Sifre ayarla
passwd --delete live 2>/dev/null || true
echo "live:live" | chpasswd

# Home izinleri
chown -R live:live /home/live
chmod 700 /home/live

# Home dizinine dosyalari kopyala
cp /etc/skel/.bash_profile /home/live/.bash_profile 2>/dev/null || true
cp /etc/skel/.xinitrc /home/live/.xinitrc 2>/dev/null || true
chmod 644 /home/live/.bash_profile 2>/dev/null || true
chmod 755 /home/live/.xinitrc 2>/dev/null || true
chown -R live:live /home/live

# /tmp izni
chmod 1777 /tmp

# D-Bus
dbus-uuidgen --ensure=/etc/machine-id 2>/dev/null || true

# Installer izni
chmod 755 /usr/bin/hiroki-installer 2>/dev/null || true

# NetworkManager
systemctl enable NetworkManager.service 2>/dev/null || true
systemctl enable sshd.service 2>/dev/null || true

# multi-user default (login → startx)
systemctl set-default multi-user.target 2>/dev/null || true
