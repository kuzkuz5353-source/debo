#!/usr/bin/env bash
# Hiroki OS - Display Manager Kurulumu
# Seçilen DE'ye göre uygun DM'yi etkinleştirir
set -euo pipefail
DE="${1:-xfce}"
echo "[Hiroki DM] DE: $DE için DM ayarlanıyor"

# Tüm DM'leri devre dışı bırak, doğru olanı etkinleştir
systemctl disable lightdm.service 2>/dev/null || true
systemctl disable sddm.service 2>/dev/null || true
systemctl disable gdm.service 2>/dev/null || true
systemctl disable ly.service 2>/dev/null || true

case "$DE" in
    kde)
        echo "[Hiroki DM] SDDM seçildi (KDE)"
        systemctl enable sddm.service 2>/dev/null || systemctl enable sddm 2>/dev/null || true
        # SDDM Hiroki teması
        if [[ -d /usr/share/sddm/themes/hiroki ]]; then
            mkdir -p /etc/sddm.conf.d
            cat > /etc/sddm.conf.d/hiroki.conf <<'EOS'
[Theme]
Current=hiroki
CursorTheme=Bibata-Modern-Classic
EOS
        fi
        ;;
    gnome)
        echo "[Hiroki DM] GDM seçildi (GNOME)"
        systemctl enable gdm.service 2>/dev/null || true
        ;;
    i3wm|hyprland)
        # Hyprland için sddm tercih, ama lightdm de olur
        if [[ "$DE" == "hyprland" ]]; then
            echo "[Hiroki DM] SDDM seçildi (Hyprland Wayland)"
            systemctl enable sddm.service 2>/dev/null || systemctl enable lightdm.service 2>/dev/null || true
        else
            echo "[Hiroki DM] LightDM seçildi (i3wm)"
            systemctl enable lightdm.service 2>/dev/null || true
        fi
        ;;
    xfce|cinnamon|mate|budgie|lxqt|openbox|*)
        echo "[Hiroki DM] LightDM seçildi ($DE)"
        systemctl enable lightdm.service 2>/dev/null || true
        # LightDM GTK greeter Hiroki teması
        mkdir -p /etc/lightdm 2>/dev/null || true
        if [[ -f /etc/lightdm/lightdm-gtk-greeter.conf ]]; then
            cat > /etc/lightdm/lightdm-gtk-greeter.conf <<'EOS'
[greeter]
background=/usr/share/hiroki/wallpapers/sakura-gradient.jpg
theme-name=Hiroki-Dark
icon-theme-name=Hiroki-Icons
cursor-theme-name=Bibata-Modern-Classic
font-name=Inter 10
xft-antialias=true
xft-hintstyle=hintfull
indicators=~host;~spacer;~clock;~spacer;~language;~session;~a11y;~sound;~power
clock-format=%A %d %B %H:%M
position=x 50% y 50%
EOS
        else
            cat > /etc/lightdm/lightdm-gtk-greeter.conf <<'EOS'
[greeter]
background=/usr/share/hiroki/wallpapers/sakura-gradient.jpg
theme-name=Hiroki-Dark
icon-theme-name=Hiroki-Icons
EOS
        fi
        # lightdm.conf - autologin kapalı, varsayılan session
        if [[ -f /etc/lightdm/lightdm.conf ]]; then
            # Session'ı DE'ye göre ayarla
            case "$DE" in
                xfce) SESSION="xfce" ;;
                cinnamon) SESSION="cinnamon" ;;
                mate) SESSION="mate" ;;
                budgie) SESSION="budgie-desktop" ;;
                lxqt) SESSION="lxqt" ;;
                openbox) SESSION="openbox" ;;
                i3wm) SESSION="i3" ;;
                *) SESSION="xfce" ;;
            esac
            # lightdm.conf içinde user-session ayarla (varsa)
            if grep -q "^\[Seat:\*\]" /etc/lightdm/lightdm.conf; then
                sed -i "s/^#*user-session=.*/user-session=$SESSION/" /etc/lightdm/lightdm.conf 2>/dev/null || true
            fi
        fi
        ;;
esac

echo "[Hiroki DM] DM kurulumu tamamlandı"
