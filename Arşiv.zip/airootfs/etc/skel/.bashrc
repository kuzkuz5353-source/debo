# Hiroki OS - .bashrc
# Sakura 1.0 - Hiroki renkleri ve karşılama

# Eğer interaktif değilse çık
[[ $- != *i* ]] && return

# Renkli prompt - Hiroki mor (#2D1B69) ve pembe (#E91E8C)
PS1='\[\033[1;35m\]🌸 \[\033[1;34m\]\u@\h\[\033[0m\] \[\033[1;30m\]\w\[\033[0m\] \[\033[1;35m\]❯\[\033[0m\] '

# Aliaslar
alias ls='ls --color=auto'
alias ll='ls -lah'
alias la='ls -A'
alias l='ls -CF'
alias grep='grep --color=auto'
alias pacman='sudo pacman'
alias yay='yay --color=always'
alias update='sudo pacman -Syu'
alias htop='htop --tree'

# Hiroki komutları
alias hiroki-info='cat /etc/os-release && echo "---" && /usr/bin/hiroki-hw-detect'
alias hiroki-theme='hiroki-theme-manager'
alias hiroki-welcome='hiroki-welcome --force'

# Fastfetch / neofetch - ilk terminalde Hiroki logosu
if [[ -z "$HIROKI_BASH_DONE" ]]; then
    export HIROKI_BASH_DONE=1
    if command -v fastfetch >/dev/null 2>&1; then
        fastfetch --logo /usr/share/hiroki/ascii/hiroki.txt 2>/dev/null || fastfetch 2>/dev/null | head -n 20
    elif command -v neofetch >/dev/null 2>&1; then
        neofetch 2>/dev/null | head -n 20
    else
        cat /usr/share/hiroki/ascii/hiroki.txt 2>/dev/null || echo "Hiroki OS 1.0 Sakura 🌸"
        echo "Hoş geldin, $(whoami)! Hiroki OS Sakura'ya hoş geldin."
    fi
    echo -e "\033[0;35mHiroki ipucu:\033[0m Tema değiştirmek için \033[1m hiroki-theme-manager\033[0m yaz."
fi

# AUR helper bilgisi
if ! command -v yay >/dev/null 2>&1 && ! command -v paru >/dev/null 2>&1; then
    echo -e "\033[1;33mAUR helper kurulu değil. Kurmak için: sudo pacman -S yay\033[0m"
fi

# History
HISTSIZE=10000
HISTFILESIZE=20000
HISTCONTROL=ignoreboth
shopt -s histappend
