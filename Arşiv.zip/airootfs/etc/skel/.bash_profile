# Hiroki OS - TTY login'den sonra XFCE baslat
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    exec startx
fi
